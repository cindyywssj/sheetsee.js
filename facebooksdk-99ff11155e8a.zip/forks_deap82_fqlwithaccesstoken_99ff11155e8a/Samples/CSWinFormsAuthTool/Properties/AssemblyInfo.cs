﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Facebook.Samples.AuthenticationTool")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCompany("Thuzi, LLC")]
[assembly: AssemblyProduct("Facebook C# SDK")]
[assembly: AssemblyCopyright("Copyright © Thuzi, LLC 2010")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyFileVersion("1.0.0.0")]
