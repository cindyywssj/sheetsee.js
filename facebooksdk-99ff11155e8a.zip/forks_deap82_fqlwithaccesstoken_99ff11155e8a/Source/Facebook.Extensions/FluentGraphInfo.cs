﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Facebook
{
    public class FluentGraphInfo
    {

        public string Path { get; set; }

    }
}
