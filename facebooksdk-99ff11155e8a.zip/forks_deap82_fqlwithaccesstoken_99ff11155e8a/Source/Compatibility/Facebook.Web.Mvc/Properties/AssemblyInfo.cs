﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Facebook.Web.Mvc")]
[assembly: InternalsVisibleTo("Facebook.Web.Mvc.Tests, PublicKey=" + GlobalAssemblyInfo.PublicKey)]