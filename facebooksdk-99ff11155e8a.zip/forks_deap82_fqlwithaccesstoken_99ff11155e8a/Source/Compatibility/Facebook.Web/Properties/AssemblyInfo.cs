﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Facebook.Web")]
[assembly: InternalsVisibleTo("Facebook.Web.Tests, PublicKey=" + GlobalAssemblyInfo.PublicKey)]
