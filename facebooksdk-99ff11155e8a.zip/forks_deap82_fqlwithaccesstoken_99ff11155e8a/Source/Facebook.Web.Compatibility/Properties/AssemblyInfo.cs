﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Facebook.Web.Compatibility")]
[assembly: AssemblyVersion("5.0.3.0")]
