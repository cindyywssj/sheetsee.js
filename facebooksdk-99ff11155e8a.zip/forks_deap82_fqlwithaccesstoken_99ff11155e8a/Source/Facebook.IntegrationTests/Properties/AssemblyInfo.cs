﻿using System.Reflection;

[assembly: AssemblyTitle("Facebook.IntegrationTests")]
